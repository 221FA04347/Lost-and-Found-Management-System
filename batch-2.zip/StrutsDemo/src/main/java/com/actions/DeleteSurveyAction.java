package com.actions;

import org.hibernate.Session;
import org.hibernate.Transaction;
import com.opensymphony.xwork2.ActionSupport;
import com.vignan.Survey;
import com.helper.FactoryProvider;

public class DeleteSurveyAction extends ActionSupport {
    private int id; // Survey ID

    public String delete() {
        Session session = FactoryProvider.getFactory().openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();
            Survey survey = session.get(Survey.class, id); // Fetch the survey by ID

            if (survey != null) {
                // Delete the survey from the database
                session.remove(survey);
                tx.commit();
                addActionMessage("Survey deleted successfully!");
                return SUCCESS;
            } else {
                addActionError("Survey with ID " + id + " not found.");
                return ERROR;
            }
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            addActionError("Error deleting survey: " + e.getMessage());
            return ERROR;
        } finally {
            session.close();
        }
    }

    // Getter and setter for the ID
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
